/* runs before the page: gives it real disk access through the main process */
const { ipcRenderer } = require("electron");
const path = require("path");
const install = require("./handles.js");
const call = (n, ...a) => ipcRenderer.invoke("fs:" + n, ...a);
install(window, {
  sep: path.sep,
  read: p => call("read", p), write: (p, d) => call("write", p, d), stat: p => call("stat", p),
  mkdir: p => call("mkdir", p), list: p => call("list", p), remove: (p, r) => call("remove", p, r),
  pickDir: () => call("pickDir"), pickFiles: (t, m) => call("pickFiles", t, m), pickSave: n => call("pickSave", n)
});
