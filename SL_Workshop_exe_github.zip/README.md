# SL Mod Workshop — exe

Редактор машин для Street Legal 1 REVision в виде программы для Windows.
В отличие от открытия в Chrome, программа пишет все файлы (включая `.cfg`) напрямую:
нет `.pending`, не нужен `SL_Apply.bat`, удаление файлов работает по-настоящему.

## Как собрать exe на GitHub
1. github.com → New repository → любое имя (например `sl-mod-workshop`) → Create.
2. «uploading an existing file» → перетащите ВСЁ содержимое этой папки (вместе с папкой `.github`) → Commit changes.
3. Вкладка **Actions** → сборка «Build exe» запустится сама (≈5 минут).
4. Откройте завершённую сборку → внизу **Artifacts** → `SL_Mod_Workshop` → скачается zip с `SL_Mod_Workshop.exe`.

## Как пользоваться
- Положите `SL_Mod_Workshop.exe` в `Street Legal 1 REVision\modding_tools`.
- Если рядом с exe лежит `SL_Mod_Workshop.html`, программа открывает его (так редактор обновляется без пересборки exe).
- Для 3D нужен интернет (библиотека three.js грузится из сети).
