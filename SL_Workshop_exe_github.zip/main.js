const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const fsp = fs.promises;

/* where the exe lies (a portable exe runs from a temp folder; the real place is in PORTABLE_EXECUTABLE_DIR) */
const exeDir = process.env.PORTABLE_EXECUTABLE_DIR || path.dirname(process.execPath);
const cfgFile = () => path.join(app.getPath("userData"), "settings.json");
const settings = (() => { try { return JSON.parse(fs.readFileSync(cfgFile(), "utf8")); } catch (e) { return {}; } })();
const save = () => { try { fs.mkdirSync(path.dirname(cfgFile()), { recursive: true }); fs.writeFileSync(cfgFile(), JSON.stringify(settings)); } catch (e) {} };

/* the editor page: a newer SL_Mod_Workshop.html next to the exe wins over the copy built into it,
   so the editor can be updated without rebuilding the exe */
function pagePath() {
  const near = path.join(exeDir, "SL_Mod_Workshop.html");
  return fs.existsSync(near) ? near : path.join(__dirname, "app", "SL_Mod_Workshop.html");
}
/* the game folder guess: the exe in ...\Street Legal 1 REVision\modding_tools */
function gameGuess() {
  if (settings.lastDir && fs.existsSync(settings.lastDir)) return settings.lastDir;
  for (const d of [path.dirname(exeDir), exeDir]) if (fs.existsSync(path.join(d, "cars"))) return d;
  return undefined;
}

ipcMain.handle("fs:read", async (e, p) => { try { const [b, s] = await Promise.all([fsp.readFile(p), fsp.stat(p)]); return { data: new Uint8Array(b), mtime: s.mtimeMs }; } catch (err) { return null; } });
ipcMain.handle("fs:write", async (e, p, d) => { await fsp.writeFile(p, Buffer.from(d)); return true; });
ipcMain.handle("fs:stat", async (e, p) => { try { const s = await fsp.stat(p); return s.isDirectory() ? "dir" : "file"; } catch (err) { return null; } });
ipcMain.handle("fs:mkdir", async (e, p) => { await fsp.mkdir(p, { recursive: true }); return true; });
ipcMain.handle("fs:list", async (e, p) => (await fsp.readdir(p, { withFileTypes: true })).map(d => [d.name, d.isDirectory() ? "dir" : "file"]));
ipcMain.handle("fs:remove", async (e, p, rec) => { await fsp.rm(p, { recursive: !!rec, force: true }); return true; });
ipcMain.handle("fs:pickDir", async e => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { properties: ["openDirectory"], defaultPath: gameGuess(), title: "Папка игры Street Legal 1 REVision" });
  if (r.canceled || !r.filePaths[0]) return null; settings.lastDir = r.filePaths[0]; save(); return r.filePaths[0];
});
ipcMain.handle("fs:pickFiles", async (e, types, multi) => {
  const filters = (types || []).map(t => ({ name: t.description || "Файлы", extensions: Object.values(t.accept || {}).flat().map(x => x.replace(/^\./, "")) }));
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { properties: multi ? ["openFile", "multiSelections"] : ["openFile"], filters: filters.length ? filters : undefined, defaultPath: gameGuess() });
  return r.canceled ? null : r.filePaths;
});
ipcMain.handle("fs:pickSave", async (e, name) => {
  const r = await dialog.showSaveDialog(BrowserWindow.fromWebContents(e.sender), { defaultPath: path.join(gameGuess() || app.getPath("documents"), name || "") });
  return r.canceled ? null : r.filePath;
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1500, height: 950, backgroundColor: "#16191d", title: "SL Mod Workshop",
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: false, nodeIntegration: false, sandbox: false }
  });
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: "deny" }; });
  win.loadFile(pagePath());
}
app.whenReady().then(createWindow);
app.on("window-all-closed", () => app.quit());
