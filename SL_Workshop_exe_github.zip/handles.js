/* File System Access API (the subset SL Mod Workshop uses) on top of plain disk access.
   In the exe the browser's own picker is replaced by this one: files are written as they are,
   .cfg included — no ".pending" copies, no SL_Apply.bat, deleting really deletes. */
(function(root){
function install(win, api){
  const err=(name,msg)=>{ const e=new Error(msg); e.name=name; return e; };
  const join=(a,b)=>a.replace(/[\\/]+$/,"")+api.sep+b;
  const base=p=>p.replace(/[\\/]+$/,"").split(/[\\/]/).pop();
  const bytes=async d=>{ if(d&&d.type==="write") d=d.data;
    if(typeof d==="string") return new TextEncoder().encode(d);
    if(d instanceof Blob) return new Uint8Array(await d.arrayBuffer());
    if(d instanceof ArrayBuffer) return new Uint8Array(d);
    if(ArrayBuffer.isView(d)) return new Uint8Array(d.buffer,d.byteOffset,d.byteLength);
    throw err("TypeError","нельзя записать "+typeof d); };
  class FileH{ constructor(p,n){ this.kind="file"; this.name=n; this._p=p; }
    async getFile(){ const r=await api.read(this._p); if(!r) throw err("NotFoundError","нет файла "+this.name); return new File([r.data],this.name,{lastModified:r.mtime}); }
    async createWritable(){ const parts=[], p=this._p; return {
      async write(d){ parts.push(await bytes(d)); },
      async close(){ let n=0; for(const x of parts) n+=x.length; const out=new Uint8Array(n); let o=0; for(const x of parts){ out.set(x,o); o+=x.length; } await api.write(p,out); },
      async abort(){ parts.length=0; } }; }
    async isSameEntry(o){ return !!o&&o._p===this._p; }
    async queryPermission(){ return "granted"; } async requestPermission(){ return "granted"; } }
  class DirH{ constructor(p,n){ this.kind="directory"; this.name=n; this._p=p; }
    async getDirectoryHandle(n,o){ const p=join(this._p,n), s=await api.stat(p);
      if(s==="dir") return new DirH(p,n); if(s==="file") throw err("TypeMismatchError",n+" — это файл");
      if(o&&o.create){ await api.mkdir(p); return new DirH(p,n); } throw err("NotFoundError","нет папки "+n); }
    async getFileHandle(n,o){ const p=join(this._p,n), s=await api.stat(p);
      if(s==="file") return new FileH(p,n); if(s==="dir") throw err("TypeMismatchError",n+" — это папка");
      if(o&&o.create){ await api.write(p,new Uint8Array(0)); return new FileH(p,n); } throw err("NotFoundError","нет файла "+n); }
    async removeEntry(n,o){ const p=join(this._p,n); if(!await api.stat(p)) throw err("NotFoundError","нет "+n); await api.remove(p,!!(o&&o.recursive)); }
    async *entries(){ for(const [n,k] of await api.list(this._p)){ const p=join(this._p,n); yield [n,k==="dir"?new DirH(p,n):new FileH(p,n)]; } }
    async *values(){ for await(const [,h] of this.entries()) yield h; }
    async *keys(){ for await(const [n] of this.entries()) yield n; }
    [Symbol.asyncIterator](){ return this.entries(); }
    async resolve(h){ const a=this._p.replace(/[\\/]+$/,"")+api.sep; return h&&h._p.startsWith(a)?h._p.slice(a.length).split(/[\\/]/):null; }
    async isSameEntry(o){ return !!o&&o._p===this._p; }
    async queryPermission(){ return "granted"; } async requestPermission(){ return "granted"; } }
  const abort=()=>err("AbortError","отменено");
  win.showDirectoryPicker=async()=>{ const p=await api.pickDir(); if(!p) throw abort(); return new DirH(p,base(p)); };
  win.showOpenFilePicker=async o=>{ const ps=await api.pickFiles(o&&o.types||[],!!(o&&o.multiple)); if(!ps||!ps.length) throw abort(); return ps.map(p=>new FileH(p,base(p))); };
  win.showSaveFilePicker=async o=>{ const p=await api.pickSave(o&&o.suggestedName||""); if(!p) throw abort(); return new FileH(p,base(p)); };
  win.SL_DESKTOP=true;
}
if(typeof module!=="undefined") module.exports=install; else root.SLInstallFS=install;
})(this);
